export class User {

}
