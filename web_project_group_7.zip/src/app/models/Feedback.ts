export class Feedback {
    title: string;
	by: string;
	rating: string;
	date: string;
	comment: string;
}
