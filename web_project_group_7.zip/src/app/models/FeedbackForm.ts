export class FeedbackForm {
    constructor(
        public title: string,
        public by: string,
        public rating: string,
        public date: string,
        public comment: string,
    ){}
}