 export class UpcomingBookings {
    ref: string;
	date: string;
    price: number;
    nights: number;
}