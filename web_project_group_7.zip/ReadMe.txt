Project - Group 7 
Web Design

References
[1] Andrew Neel unsplash 
    https://unsplash.com/photos/B4rEJ09-Puo
[2] Photo by Markus Spiske on Unsplash
    https://unsplash.com/photos/g5ZIXjzRGds
[3] Photo by NeONBRAND on Unsplash
    https://unsplash.com/photos/)
[4] Photo by Alexandra Gorn on Unsplash
    https://unsplash.com/photos/
[5] Photo by Philipp Berndt on Unsplash
    https://www.flaticon.com/free-icon/star_148841#term=star&page=1&position=2
[6] Photo by Becca Tapert on Unsplash
    https://unsplash.com/photos/
[7] Photo by Michael D Beckwith on Unsplash
    https://unsplash.com/photos/
[8] Photo by Daniil Silantev on Unsplash
    https://unsplash.com/photos/
[9] Jorge Vasconez Unsplash toronto link
    https://unsplash.com/photos/Eh1ipuQIxiY
[10]Image by 1chigo121212 from Pixabay  
    https://pixabay.com/photos/montreal-city-urban-night-lights-247795/
[11]Image by Graham Habster from Pixabay 
    https://pixabay.com/photos/halifax-nova-scotia-waterfront-2370263/



Links
  http://129.173.22.35:26543/
  http://129.173.22.35:26543/login
  http://129.173.22.35:26543/sign-up
  http://129.173.22.35:26543/feedback
  http://129.173.22.35:26543/contact
  http://129.173.22.35:26543/avaliable
  http://129.173.22.35:26543/booking-record
  

Git
  https://git.cs.dal.ca/agbola/web_project_group_7.git
File Structure
e2e
src
  app
    footer
    header
    home
    available-room
    bookings
    contact-us
    hotel-details
    login
    models
    profile
    search-filter
    signup
    booking-history
    booking-records
    feedback



Frameworks
Boostrap: this is a powerful and popular CSS framwork with and all my groupmates had experience with this framework
Angular 7: This is a power MVC Javascript Framework and most of my team members had good experience with this framework

